"""
waveslim_rats

This is a free translation of some part of the codes from Brandon Whitcher's "waveslim" package distributed in R, under a BSD 3 license, available at    
"https://cran.r-project.org/web/packages/waveslim/" into Python.
This code is given as it, and has been developped only for the purpose of the study of data of rats under anesthesia. 

Copyright: G. J.-P. C. Becq, Gipsa-lab, UMR 5216, CNRS 
Date: 2019-05-07

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B 
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.
"""
import pylab as pl

class DWT(): 
    def __init__(self, y, wf, boundary):
        self.y = y
        self.wavelet = wf
        self.boundary = boundary
        return None

def dwt(x, wf="la8", n_levels=4, boundary="periodic"): 
    # switch(boundary, "reflection" =  x = c(x, rev(x)), "periodic" = invisible(), stop("Invalid boundary rule in dwt"))
    if boundary == "reflection":
        x = pl.concatenate((x, x[::-1]))
    N = x.shape[0]
    J = n_levels
    if (N / (2 ** J) != int(N / (2 ** J))): 
        print("Sample size is not divisible by 2^J")
        return None
    if (2 ** J > N): 
        print("wavelet transform exceeds sample size in dwt")
        return None
    dic = wave_filter(wf)
    L = dic["length"]
    h = dic["hpf"]
    g = dic["lpf"]
    y = []
    for j in range(1, J + 1):
        # print(j, N / (2 ** (j - 1)))
        (W, V) = pydwt(x, N / (2 ** (j - 1)), L, h, g)
        y.append(W)
        x = V
    y.append(x)
    d = DWT(y, wf, boundary)
    return d

def pydwt(Vin, M, L, h, g): 
    """
    py version of C code
    """
    N = Vin.shape[0]
    Wout = pl.zeros((int(M / 2), ))
    Vout = pl.zeros((int(M / 2), ))
    for t in range(int(M / 2)): 
        u = 2 * t + 1
        Wout[t] = h[0] * Vin[u]
        Vout[t] = g[0] * Vin[u]
        for n in range(1, L): 
            u -= 1;
            if (u < 0): 
                u = M - 1
            u = int(u)
            Wout[t] += h[n] * Vin[u]
            Vout[t] += g[n] * Vin[u]
    return (Wout, Vout)

def qmf(g, low2high=True): 
    """
    """
    L = g.shape[0]
    if low2high: 
        h = (-1) ** pl.arange(L) * g[::-1]
    else: 
        h = (-1) ** pl.arange(1, L + 1) * g[::-1]
    return h

def wave_filter(wf): 
    """
    """
    dic = {}
    if wf == 'la8':
        g = pl.array([-0.07576571478935668, -0.02963552764596039, 
                0.49761866763256290, 0.80373875180538600, 
                0.29785779560560505, -0.09921954357695636, 
                -0.01260396726226383, 0.03222310060407815])
        h = qmf(g)
        dic["length"] = 8
        dic["hpf"] = h
        dic["lpf"] = g
    return dic

class MODWT(): 
    def __init__(self, y, wf, boundary):
        self.y = y
        self.wavelet = wf
        self.boundary = boundary
        return None

def modwt(x, wf="la8", n_levels=4, boundary="periodic"): 
    if boundary == "reflection":
        x = pl.concatenate((x, x[::-1]))
    N = x.shape[0]
    J = n_levels
    if (2 ** J > N): 
        print("wavelet transform exceeds sample size in modwt")
        return None
    dic = wave_filter(wf)
    L = dic["length"]
    ht = dic["hpf"] / pl.sqrt(2)
    gt  = dic["lpf"] / pl.sqrt(2)
    y = []
    W = pl.zeros((N, ))
    V = pl.zeros((N, ))
    for j in range(1, J + 1): 
        (W, V) = pymodwt(x, N, j, L, ht, gt)
        y.append(W.copy())
        x = V.copy()
    y.append(x.copy())
    d = MODWT(y, wf, boundary)
    return d

def pymodwt(Vin, N, j, L, ht, gt):
    """
    """
    Wout = pl.zeros((N, ))
    Vout = pl.zeros((N, ))
    for t in range(N): 
        k = t
        Wout[t] = ht[0] * Vin[k]
        Vout[t] = gt[0] * Vin[k]
        for n in range(1, L): 
            k -= 2 ** (j - 1)
            if (k < 0): 
                k += N
            Wout[t] += ht[n] * Vin[k]
            Vout[t] += gt[n] * Vin[k]
    return (Wout, Vout)

def brick_wall(x, wf, method="modwt"): 
    """
    x is a list containing the arrays of coefficients at the different levels.
    """
    dic = wave_filter(wf)
    m = dic["length"]
    J = len(x)
    y = []
    for j in range(1, J): 
        if (method == "dwt"): 
            n = int(pl.ceil((m - 2) * (1 - 1 / (2 ** j))))
        else : 
            n = int((2 ** j - 1) * (m - 1))
        n = min(n, x[j].shape[0])
        y.append(x[j - 1].copy())
        y[j - 1][: n] = pl.nan
    y.append(x[J - 1].copy())
    y[J - 1][: n] = pl.nan
    return y

def brick_wall_wo_nan(x, wf, method="modwt"): 
    """
    x is a list containing the arrays of coefficients at the different levels.
    
    remove nan value at the beginning
    """
    dic = wave_filter(wf)
    m = dic["length"]
    J = len(x)
    y = []
    for j in range(1, J): 
        if (method == "dwt"): 
            n = int(ceil((m - 2) * (1 - 1 / (2 ** j))))
        else : 
            n = int((2 ** j - 1) * (m - 1))
        n = min(n, x[j].shape[0])
        y.append(x[j - 1][n: ])
    y.append(x[J - 1][n: ])
    return y
