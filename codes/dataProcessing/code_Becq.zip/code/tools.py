"""
Some tools to manage data and plot figures for rats under anesthesia. 


Copyright: G. J.-P. C. Becq, Gipsa-lab, UMR 5216, CNRS  
Date: 2019-05-07

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B 
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.
"""
import pylab as pl
import numpy as np
from scipy import stats
from scipy import signal
import pandas as pd
import warnings
from scipy.stats import distributions
import igraph
import matplotlib.patches as patches
import matplotlib.pyplot as pyplot

PN_DATA = '../data'
FN_AREA = PN_DATA + '/area.csv'
FN_TRIAL = PN_DATA + '/trial.csv'
FN_CBF = PN_DATA + '/cbf.csv'

L_AREA = ['ACC', 'Ins_r', 'APir_r', 'AU_r', 'Ent_r', 'Par_r', 'M1_r', 'M2_r', 
    'RSC_r', 'S1_r', 'S1BF_r', 'S2_r', 'TeA_r', 'V1_r', 'V2_r', 'Ins_l', 
    'APir_l', 'AU_l', 'Ent_l', 'Par_l', 'M1_l', 'M2_l', 'RSC_l', 'S1_l', 
    'S1BF_l', 'S2_l', 'TeA_l', 'V1_l', 'V2_l', 'CPu_r', 'BG_r', 'Th_r', 
    'Sep_r', 'H_r', 'DSC_r', 'pag_r', 'BF_r', 'PT_r', 'HIP_r', 'S_r', 'CPu_l', 
    'BG_l', 'Th_l', 'Sep_l', 'H_l', 'DSC_l', 'pag_l', 'BF_l', 'PT_l', 'HIP_l', 
    'S_l']
L_GROUP = ['ETO_L', 'ISO_L', 'ISO_W', 'MED_L', 'URE_L', 'DEAD']
L_GROUP_NAME = ['Eto-L', 'Iso-L', 'Iso-W', 'Med-L', 'Ure-L', 'Dead']
L_GROUP_COLOR = ['g', 'r', 'r', 'm', 'b', 'k']
L_GROUP_MARKER = ['o', 'o', 'd', 'o', 'o', 'o']
N_GROUP = len(L_GROUP)
N_AREA = len(L_AREA)
N_OBS = 3600
N_C = N_AREA * (N_AREA - 1) / 2
ALPHA = 0.05
P_BONF = ALPHA / 2 / N_C
L_SCALE = ['cD1', 'cD2', 'cD3', 'cD4', 'cD5', 'cD6', 'cD7', 'cA7']

cmGB = np.random.rand(500, 3) * 256
cmGB = np.ones((300, 3)) * 196
n = 13
for i in range(n): 
    k = 255 - (n - (i + 1)) / n * 128
    cmGB[n * i + 0, :] = np.array([k, 255, 255])
    cmGB[n * i + 1, :] = np.array([255, k, 255])
    cmGB[n * i + 2, :] = np.array([255, 255, k])
    cmGB[n * i + 3, :] = np.array([k, k/2, 255])
    cmGB[n * i + 4, :] = np.array([k, 255, k/2])
    cmGB[n * i + 5, :] = np.array([255, k, k/2])
    cmGB[n * i + 6, :] = np.array([k/2, k, 255])
    cmGB[n * i + 7, :] = np.array([k, k/3, 255])
    cmGB[n * i + 8, :] = np.array([255, k, k/3])
    cmGB[n * i + 9, :] = np.array([255, k/3, k])
    cmGB[n * i + 10, :] = np.array([k/3, 255, k])
    cmGB[n * i + 12, :] = np.array([k, 255, k/3])

df_cog = pd.read_csv(PN_DATA + '/area.csv', index_col='LABEL')
X = df_cog.loc[L_AREA]['X'].values
Y = df_cog.loc[L_AREA]['Y'].values
Z = df_cog.loc[L_AREA]['Z'].values
XY = [(X[i], Y[i]) for i in range(N_AREA)]
ZY = [(Z[i], Y[i]) for i in range(N_AREA)]
XZ = [(X[i], Z[i]) for i in range(N_AREA)]


class Record(): 
    def __init__(self, df_db, i):
        name = df_db.loc[i, 'NAME']
        group = df_db.loc[i, 'GROUP']
        fn = '../data/raw/{0}_raw.csv'.format(name)
        df_raw = pd.read_csv(fn)
        x = df_raw[L_AREA].values.T
        fn = '../data/cD4/{0}_cD4.csv'.format(name)
        df_cd4 = pd.read_csv(fn)
        x4 = df_cd4[L_AREA].values.T
        rr = df_raw['RESP_RATE'].values
        temp = df_raw['TEMP_1'].values
        spo2 = df_raw['SPO2'].values
        hr = df_raw['HEART_RATE'].values
        err = df_raw['ERROR_CODE'].values
        fn_coreg = '../data/coreg/rp_' + name + '.txt'
        coreg = pl.loadtxt(fn_coreg)
        t = pl.arange(0, 1800, 0.5)
        mx = pl.mean(x, 1)
        fd = get_framewise_displacement(coreg)
        self.i = i
        self.name = name
        self.group = group
        self.t = t
        self.coreg = coreg
        self.x = x
        self.x4 = x4
        self.rr = rr
        self.hr = hr
        self.temp = temp
        self.spo2 = spo2
        self.err = err
        self.mx = mx
        self.fd = fd

def get_corr_norm(xi, xj): 
    a = pl.correlate(xi, xj, 'full')
    a /= pl.sqrt(np.dot(xi, xi) * np.dot(xj, xj))
    return a

def get_x_i(df_db, i, ext='raw'): 
    name = df_db.loc[i, 'NAME']
    fn = PN_DATA + '/{1}/{0}_{1}.csv'.format(name, ext)
    df_x = pd.read_csv(fn)
    x = df_x[L_AREA].values
    return x
    
    
def get_x(df_db, name, fn, i=0):     
    i_rat_db = int(pl.where(df_db['NAME'] == name)[0])
    #ds = get_i_lag_ws(i)
    df_x = pd.read_csv(fn)
    fmri_x = df_x[L_AREA].values.astype('float')
    fmri_std = pl.std(fmri_x, 0)
    hr = df_x['HEART_RATE'].values.astype('float')
    rr = df_x['RESP_RATE'].values.astype('float')
    temp = df_x['TEMP_1'].values.astype('float')
    return (fmri_x, fmri_std, hr, rr, temp)

def get_x_no_mvt(df_db, name, fn, i=0): 
    """
    (fmri_x, fmri_std, hr, rr, temp) = get_x_no_mvt(df_db, name, fn, i=0)
    """
    ds = get_i_lag_ws(i)
    df_it = pd.read_csv(PN_DATA +'/i_select/{0}.csv'.format(name))
    it = df_it.values[i, 1:].astype('bool')
    # print(it.dtype)
    # print(sum(it))
    if i == 0: 
        df_x = pd.read_csv(fn)
        fmri_x_0 = df_x[L_AREA].values.astype('float')
        fmri_x = fmri_x_0[it, :]
        fmri_std = pl.std(fmri_x, 0)
        hr_0 = df_x['HEART_RATE'].values.astype('float')
        hr = hr_0[it]
        rr_0 = df_x['RESP_RATE'].values.astype('float')
        rr = rr_0[it]
        temp_0 = df_x['TEMP_1'].values.astype('float')
        temp = temp_0[it]
    else: 
        df_x = pd.read_csv(fn)
        fmri_x_0 = df_x[L_AREA].values.astype('float')
        n = fmri_x_0.shape[0]
        pad = int((3600 - n) / 2)
        fmri_x = np.zeros((3600, 51))
        fmri_x[pad + 1: -pad, :] = fmri_x_0
        fmri_x = fmri_x[it, :]
        fmri_std = pl.std(fmri_x, 0)
        hr_0 = df_x['HEART_RATE'].values.astype('float')
        hr = np.zeros((3600))
        hr[pad + 1: -pad]= hr_0
        hr = hr[it]
        rr_0 = df_x['RESP_RATE'].values.astype('float')
        rr = np.zeros((3600))
        rr[pad + 1: -pad] = rr_0
        rr = rr[it]
        temp_0 = df_x['TEMP_1'].values.astype('float')
        temp = np.zeros((3600))
        temp[pad + 1: -pad] = temp_0
        temp = temp[it]
    # it = eval(df_db['IT_VALID'][i_rat_db])
    # i_0 = int(it[0][0] - ds)
    # i_1 = int(it[0][1] - ds)
    # fmri_x = df_cD4[L_AREA].values[i_0: i_1, :].astype('float')
    # hr = df_x['HEART_RATE'].values[i_0: i_1].astype('float')
    #rr = df_x['RESP_RATE'].values[i_0: i_1].astype('float')
    # temp = df_x['TEMP_1'].values[i_0: i_1].astype('float')
    return (fmri_x, fmri_std, hr, rr, temp)
    
def red_cent(x): 
    m = pl.mean(x)
    s = pl.std(x)
    return (x - m) / s

def remove_autapse(C): 
    n = C.shape[0]
    for i in range(n): 
        C[i, i] = 0
    return C

def find_c_rank(C, n): 
    C_flat = C.flatten()
    s_c = pl.sort(np.abs(C_flat)) # count 2 times the same values for C[i,j] = C[j,i] emplies n = 2 * n_cut
    val = s_c[-n] 
    return (val, s_c)

def nan_to_zero(A):
    cond_1 = pl.isnan(A)
    B = A.copy()
    B[cond_1] = 0
    return B

def get_C_no_mvt(df_db, name, fn, i=0, n_l=1, th=0): 
    """
    (x, s, C, FCS, val, s_c, FCS_hr, FCS_rr, FCS_temp, A) = get_C_no_mvt(df_db, name, fn, n_l=1, th=0)
    """
    (x, s, hr, rr, temp) = get_x_no_mvt(df_db, name, fn, i=i)
    x_all = pl.c_[x, hr, rr, temp]
    C1 = pl.corrcoef(x_all.T)
    i_hr = N_AREA
    i_rr = N_AREA + 1
    i_temp = N_AREA + 2
    FCS_hr = pl.sum(C1[i_hr, :N_AREA]) / N_AREA
    FCS_rr = pl.sum(C1[i_rr, :N_AREA]) / N_AREA
    FCS_temp = pl.sum(C1[i_temp, :N_AREA]) / N_AREA
    C1 = C1[: N_AREA, : N_AREA]
    C = nan_to_zero(C1)
    C = remove_autapse(C)
    (val, s_c) = find_c_rank(C, n_l)
    FCS = pl.sum(C, 1) / (N_AREA - 1)
    A = (C > th).astype('int')
    return (x, s, C, FCS, val, s_c, FCS_hr, FCS_rr, FCS_temp, A)

def get_distrib_connection(A, verbose=True):
    """
    A is an adjacency matrix (0 or 1)
    """
    n_v = A.shape[0]
    A = remove_autapse(A)
    n_e = np.sum(A.flatten())
    density = n_e / (n_v * (n_v - 1))
    if verbose: print('n_e: ', n_e)
    if verbose: print('n_v: ', n_v)
    if verbose: print('density: ', density)
    # print(labels_ret)
    i_acc = np.array([0], 'int')
    i_right = np.r_[np.arange(1, 15), np.arange(29, 40)].astype('int')
    i_left = np.r_[np.arange(15, 29), np.arange(40, 51)].astype('int')
    i_cor = np.arange(1, 29).astype('int')
    i_sub = np.arange(29, 51).astype('int')
    # print(i_acc)
    # print([labels_ret[i] for i in i_acc])
    # print([labels_ret[i] for i in i_right])
    # print([labels_ret[i] for i in i_left])
    # print([labels_ret[i] for i in i_cor])
    # print([labels_ret[i] for i in i_sub])
    res = ''
    res_i = []
    A_1 = A[i_acc, :]
    n_3 = np.sum(A_1) * 2 / n_e
    if verbose: print('ACC: ', np.around(n_3 * 100, 2))
    res += (str(np.around(n_3 * 100, 2)) + ' & ')
    res_i.append(n_3)
    A_1 = A[i_left, :]
    A_1 = A_1[:, i_right]
    n_1 = np.sum(A_1) / n_e
    A_1 = A[i_right, :]
    A_1 = A_1[:, i_left]
    n_2 = np.sum(A_1) / n_e
    n_3 = n_1 + n_2
    if verbose: print('interhemi: ', np.around(n_3 * 100, 2))
    res += (str(np.around(n_3 * 100, 2)) + ' & ')
    res_i.append(n_3)
    A_1 = A[i_left, :]
    A_1 = A_1[:, i_left]
    n_1 = np.sum(A_1) / n_e
    A_1 = A[i_right, :]
    A_1 = A_1[:, i_right]
    n_2 = np.sum(A_1) / n_e
    n_3 = n_1 + n_2
    if verbose: print('ipsi: ', np.around(n_3 * 100, 2))
    res += (str(np.around(n_3 * 100, 2)) + ' & ')
    res_i.append(n_3)
    A_1 = A[i_cor, :]
    A_1 = A_1[:, i_cor]
    n_3 = np.sum(A_1) / n_e
    if verbose: print('cor-cor: ', np.around(n_3 * 100, 2))
    res += (str(np.around(n_3 * 100, 2)) + ' & ')  
    res_i.append(n_3)
    A_1 = A[i_sub, :]
    A_1 = A_1[:, i_sub]
    n_3 = np.sum(A_1) / n_e
    if verbose: print('sub-sub: ', np.around(n_3 * 100, 2))
    res += (str(np.around(n_3 * 100, 2)) + ' & ')   
    res_i.append(n_3)
    A_1 = A[i_sub, :]
    A_1 = A_1[:, i_cor]
    n_1 = np.sum(A_1) / n_e
    A_1 = A[i_cor, :]
    A_1 = A_1[:, i_sub]
    n_2 = np.sum(A_1) / n_e
    n_3 = n_1 + n_2
    if verbose: print('cor-sub: ', np.around(n_3 * 100, 2))
    res += (str(np.around(n_3 * 100, 2)) + ' \\\\ ')
    res_i.append(n_3)
    if verbose: print(res)
    return res_i

def get_n_over_q(C, q):
    N = C.shape[0]
    n_e = N * (N - 1) / 2
    n = int((pl.sum(C >= q) - N) / 2)
    rho = n / n_e
    return (n, rho)

def get_n_corr_over_th(C, th):
    n = C.shape[0]
    n_e = int(n * (n - 1) / 2)
    n_over_th = 0
    for i in range(n): 
        for j in range(i + 1, n): 
            if C[i, j] >= th: 
                n_over_th += 1
    return (n_over_th, n_over_th / n_e) 

def get_df_select_no_mvt(fd, th=0.1): 
    l_scale = [0, 1, 2, 3, 4, 5, 6, 7, 7]
    l_index = ['raw', 'cD1', 'cD2', 'cD3', 'cD4', 'cD5', 'cD6', 'cD7', 'cA7']
    df_select = pd.DataFrame(index=l_index, columns=pl.arange(3600))
    fd_temp = np.zeros((3600, ), dtype='bool')
    for (i, index) in enumerate(l_index): 
        scale = l_scale[i]
        fd2 = (fd > th).astype('float')
        fd2 = signal.lfilter(np.ones((40,)), 1, fd2)[:3600]
        if scale == 0: 
            ds = 1
            fd_temp = fd2.astype('bool')
            df_select.loc[index, :] = ~fd_temp
        else: 
            ds = get_i_lag_ws(scale)
            fd2[0] = True
            fd2[-1] = True
            #plot(fd2)
            b = pl.ones(ds)
            a = 1
            warnings.filterwarnings('ignore')
            fd_f1 = signal.filtfilt(b, a, fd2)
            fd_temp = fd_f1.astype('bool')
            df_select.loc[index, :] = ~fd_temp
    return df_select


def get_df_select_no_mvt_from_interval(l_interval, t_hrf=10): 
    l_scale = [0, 1, 2, 3, 4, 5, 6, 7, 7]
    l_index = ['raw', 'cD1', 'cD2', 'cD3', 'cD4', 'cD5', 'cD6', 'cD7', 'cA7']
    df_select = pd.DataFrame(index=l_index, columns=pl.arange(3600))
    mvt_temp_0 = np.ones((3600, ), dtype='bool')
    n_hrf = 2 * t_hrf
    for it in l_interval: 
        mvt_temp_0[it[0]: it[1]] = False
    mvt_temp_0 = signal.lfilter(np.ones((n_hrf,)), n_hrf, mvt_temp_0)
    for (i, index) in enumerate(l_index):
        mvt_temp = (mvt_temp_0 > 0)
        scale = l_scale[i]
        if scale == 0: 
            df_select.loc[index, :] = ~mvt_temp
        else: 
            ds = get_i_lag_ws(scale)
            mvt_temp[0] = True
            mvt_temp[-1] = True
            #plot(fd2)
            b = pl.ones(ds)
            a = 1
            warnings.filterwarnings('ignore')
            mvt_temp = signal.filtfilt(b, a, mvt_temp)
            df_select.loc[index, :] = (mvt_temp == 0)
    return df_select

    
def get_l_ij_to_i_j(n):
    """
    >>> l_ij = get_l_ij_to_i_j(3)
    >>> print(l_ij)
    
    [(0, 1), (0, 2), (1, 2)] 
    """
    
    l_ij = []
    for i in range(n): 
        for j in range(i + 1, n): 
            l_ij.append((i, j))
    return l_ij

L_IJ = get_l_ij_to_i_j(N_AREA)

def get_flat_upper_c(C): 
    """
    >>> C_1 = array([[1, 2, 3], [2, 1, 4], [3, 4, 1]])
    >>> tools.get_flat_upper_C(C_1)
    
    array([2, 3, 4])
    """
    n = C.shape[0]
    n_e = int(n * (n - 1) / 2)
    c_u = np.zeros((n_e, ))
    l = 0
    for i in range(n): 
        for j in range(i + 1, n): 
            k = j - i - 1 + l 
            c_u[k] = C[i, j]
        l += (n - i - 1)            
    return c_u

def minmax(x, t_minmax=(0, 1)): 
    (xmin, xmax) = t_minmax
    return (x - xmin) / (xmax - xmin)

def mysavefig(fn, dpi=300): 
    pl.savefig(fn + '.png', bbox_inches = 'tight', pad_inches=0.1/2.54, dpi=dpi)
    pl.savefig(fn + '.pdf', bbox_inches = 'tight', pad_inches=0.1/2.54)


def savefig_C_group(C, group, n_l, n_rat_this_group, s_density, **kwargs):
    i_group = L_GROUP.index(group)
    groupname = L_GROUP_NAME[i_group]
    C /= n_rat_this_group
    C = nan_to_zero(C)
    C = remove_autapse(C)
    (val, s_c) = find_c_rank(abs(C), n_l)
    threshold = 0.273
    val = np.max([val, threshold])
    cond = (np.abs(C) > val)
    A = cond.astype('int')
    print('_____')
    print(groupname)
    print(get_distrib_connection(A))
    g = igraph.Graph.Adjacency(A.tolist(), mode=igraph.ADJ_UNDIRECTED)
    vd = g.community_fastgreedy()
    cl1 = vd.as_clustering(vd.optimal_count)
    #print("optimal_count: " + str(vd.optimal_count))
    colors_v = [''] * n_l
    for (i, v) in enumerate(g.vs): 
        colors_v[i] = (0.75, 0.75, 0.75)
    nc = len(cl1)
    size_c = np.zeros((nc, ))
    for (i, c) in enumerate(cl1): 
        size_c[i] = len(c)
    asortc = np.argsort(size_c)
    for (i, c) in enumerate(cl1): 
        if len(c) > 1: 
            #print(k)
            k1 = np.where(asortc == i)[0]
            k = nc - k1[0] - 1
            for j in c: 
                #print(int(cmGB[k, 0])/255, int(cmGB[k, 1])/255, int(cmGB[k, 2])/255)
                colors_v[j] = (int(cmGB[k, 0])/255, int(cmGB[k, 1])/255, int(cmGB[k, 2])/255)
                # print(colors_v[i])
        else: 
            i = c[0]
            #print(i)
            colors_v[i] = (0.75, 0.75, 0.75)
    s_n_l = str(n_l)
    fn = '../fig/no_mvt_graph_' + s_density + '_' + group  
    flag_marker = False
    mode = 'no_label'
    flag_axis = False
    if groupname == 'Dead': 
        flag_marker = True
        flag_axis = True
        mode = 'light'
    savefig_graph(
        g, fn + '.png', labels=L_AREA, vertex_size=7, edge_size=1, 
        alpha_edges=0.5, colors=colors_v, flag_marker=flag_marker, 
        flag_density=True, metadata=(val, n_rat_this_group, groupname), 
        mode=mode, flag_axis=flag_axis, alpha_level=0.02, flag_alpha=True, 
        **kwargs)
    print('_____')
    return None

def savefig_graph(g, fn, labels=None, vertex_size=20, edge_size=2, colors=None, 
                flag_marker=False, flag_label=False, flag_density=True, metadata=None, 
                alpha_edges=1, mode='normal', p_density=2, flag_axis=False, 
                alpha_level=0.02, flag_alpha=False, fig=None, flag_weight=False):
    if fig == None: 
        pl.figure(figsize=(27/21 * 9/2.54, 9/2.54), dpi=300)
    ax = pl.plot()
    density = g.density()
    # t_axis = ([-8.5, 8.5, -9.5, 0.5], [-8.5, 2.5, -9.5, 0.5], [-8.5, 8.5, -8.5, 2.5])
    layout1 = igraph.Layout(coords=XY)
    layout2 = igraph.Layout(coords=ZY)
    layout3 = igraph.Layout(coords=XZ)
    t_layout = (layout1, layout2, layout3)
    adjust_x = np.array([0, 16.5, 0] )
    adjust_y = np.array([0, 0, 8.5] )
    axis_layout_h = np.array([[[-7, 7], [0, 0]], [[-7.6, 2.6], [0, 0]], [[-7, 7], [0, 0]]])
    axis_layout_v = np.array([[[0, 0], [-9.1, 0.5]], [[0, 0], [-9.1, 0.5]], [[0, 0], [-7.6, 2.6]]])
    pos_name_axis = np.array([[[-6.5, 0], [6.5, 0], [0, -8.6], [0, 0.5]], 
                           [[-7.1, 0], [2.3, 0], [0, -8.6], [0, 0.5]], 
                           [[-6.5, 0], [6.5, 0], [0, -7.1], [0, 2.3]]])
    name_axis = [['L', 'R', 'I', 'S'], ['P', 'A', 'I', 'S'], ['L', 'R', 'P', 'A']]
    
    # l_color edges
    l_cmap = pyplot.get_cmap('inferno')
    l_color = []
    for i in range(11): 
        l_color.append(l_cmap.colors[int(i / 10 * 255)])
     
    for i_layout in range(3): 
        layout = t_layout[i_layout]
        if colors == None: 
            colors = []
            for i in range(len(g.vs)): 
                colors.append((1, 0, 0))
        if labels == None: 
            labels = []
            for i in range(len(g.vs)): 
                labels.append(i)

        #print(layout.coords)
        for (i, v) in enumerate(g.vs): 
            # Vertices
            if mode == 'void': 
                pl.plot(layout.coords[i][0] + adjust_x[i_layout], 
                     layout.coords[i][1] + adjust_y[i_layout], 
                     'x', color=colors[i], markersize=vertex_size, alpha=1, markeredgewidth=0.4)
            else: 
                pl.plot(layout.coords[i][0] + adjust_x[i_layout], 
                     layout.coords[i][1] + adjust_y[i_layout], 
                     'o', color=colors[i], markersize=vertex_size, alpha=0.5, markeredgewidth=0)
        for (i, ed) in enumerate(g.es):
            i_in = int(ed.source)
            i_out = int(ed.target)
            X = [layout.coords[i_in][0] + adjust_x[i_layout], layout.coords[i_out][0] + adjust_x[i_layout]]
            Y = [layout.coords[i_in][1] + adjust_y[i_layout], layout.coords[i_out][1] + adjust_y[i_layout]]
            # Edges
            if flag_weight:
                w = ed['weight']
                if not(np.isnan(w)): 
                    pl.plot(X, Y, '-k', linewidth=edge_size, 
                        color=l_color[int(w * 10)], alpha=alpha_edges, zorder=int(w*10))
            else: 
                pl.plot(X, Y, '-k', linewidth=edge_size, alpha=alpha_edges)
        # Axis if void
        if (mode == 'void') | flag_axis: 
            pl.plot(axis_layout_h[i_layout, 0, :] + adjust_x[i_layout], 
                 axis_layout_h[i_layout, 1, :] + adjust_y[i_layout], '-k', linewidth=0.5, alpha=0.1)
            pl.plot(axis_layout_v[i_layout, 0, :] + adjust_x[i_layout], 
                 axis_layout_v[i_layout, 1, :] + adjust_y[i_layout], '-k', linewidth=0.5, alpha=0.1)
            pl.plot(0 + adjust_x[i_layout], 0 + adjust_y[i_layout], 'xk', markersize=0.1)
            pl.text(0 + adjust_x[i_layout], 0 + adjust_y[i_layout], 'Bregma', 
                 verticalalignment='center', fontsize=3, color='k', 
                 horizontalalignment='center', alpha=1)
            for i_name_axis in range(4): 
                pl.text(pos_name_axis[i_layout, i_name_axis, 0] + adjust_x[i_layout], 
                     pos_name_axis[i_layout, i_name_axis, 1] + adjust_y[i_layout], 
                     name_axis[i_layout][i_name_axis], 
                     verticalalignment='center', fontsize=6, color='k', weight='bold',  
                     horizontalalignment='center', alpha=1)
        
        # NAMES
        for (i, v) in enumerate(g.vs): 
            if i_layout == 1: 
                if labels[i][-2:] == '_l': 
                    labels_i = ''
                elif labels[i][:] == 'ACC': 
                    labels_i = 'ACC'
                else : 
                    labels_i = labels[i][:-2]
            else: 
                labels_i = labels[i]
            # Area names 
            #text(layout.coords[i][0] + adjust_x[i_layout], layout.coords[i][1] + adjust_y[i_layout], 
            #     labels_i, horizontalalignment='center', 
            #    verticalalignment='center', fontsize=3, color='k', weight='black')
            if mode == 'void': 
                txt = pl.text(layout.coords[i][0] + adjust_x[i_layout], 
                           layout.coords[i][1] + adjust_y[i_layout] + 0.4, 
                           labels_i, horizontalalignment='center', alpha=1, 
                           verticalalignment='center', fontsize=3, color='k', weight='ultralight')
            elif mode == 'no_label': 
                pass
            elif mode == "dead": 
                if labels[i][:] == 'ACC': 
                    labels_i = 'ACC'
                else : 
                    labels_i = labels[i][:-2]
                txt = pl.text(layout.coords[i][0] + adjust_x[i_layout], 
                           layout.coords[i][1] + adjust_y[i_layout], 
                           labels_i, horizontalalignment='center', alpha=0.9, 
                           verticalalignment='center', fontsize=5, color='k', weight='normal')
                #txt.set_path_effects([PathEffects.withStroke(linewidth=1, foreground='k')])
            elif mode == "indiv": 
                if labels[i][:] == 'ACC': 
                    labels_i = 'ACC'
                else : 
                    labels_i = labels[i][:-2]
                txt = pl.text(layout.coords[i][0] + adjust_x[i_layout], 
                           layout.coords[i][1] + adjust_y[i_layout], 
                           labels_i, horizontalalignment='center', alpha=1, 
                           verticalalignment='center', fontsize=3, color='k')

            else: 
                txt = pl.text(layout.coords[i][0] + adjust_x[i_layout], 
                           layout.coords[i][1] + adjust_y[i_layout], 
                           labels_i, horizontalalignment='center', alpha=1, 
                           verticalalignment='center', fontsize=3, color='w')
                # txt.set_path_effects([PathEffects.withStroke(linewidth=1, foreground='k')])
        if flag_marker: 
            # 1 mm 
            pl.plot([10, 11], [1, 1], '-k', linewidth=0.5)
            pl.text(10.5, 1.5, '1 mm', horizontalalignment='center', fontsize=4)
        if flag_label: 
            pl.text(0, -10, 'LR', horizontalalignment='center', fontsize=4, color='k')
            pl.text(14, -10, 'PA', horizontalalignment='center', fontsize=4, color='k')
            pl.text(-8, -5, 'IS', rotation=90, horizontalalignment='center', fontsize=4)
            pl.text(-8, 5, 'PA', rotation=90, horizontalalignment='center', fontsize=4)
        if flag_density: 
            pl.text(14, 4, 'ρ = ' + str(pl.around(density, p_density)), horizontalalignment='center', fontsize=6)
        if flag_alpha: 
            pl.text(14, 3, 'α = ' + str(alpha_level), horizontalalignment='center', fontsize=6)
        if metadata != None: 
            pl.text(14, 5, 'C > {0:3.2f}'.format(metadata[0]), horizontalalignment='center', fontsize=6)
            if isinstance(metadata[1], str): 
                pl.text(14, 6, metadata[1], horizontalalignment='center', fontsize=6)
            else: 
                pl.text(14, 6, 'N = {0:1d}'.format(metadata[1]), horizontalalignment='center', fontsize=6)
            pl.text(14, 7.5, metadata[2], horizontalalignment='center', fontsize=8)
        pl.xticks(fontsize=6)
        pl.yticks(fontsize=6)
        #axis(t_axis[i_layout])
        pl.axis('off')
        pl.axis('equal')
        pl.axis([-7, 20, -9.5, 11.5])        
    pl.savefig(fn, dpi=300, bbox_inches='tight', pad_inches=0)
    pl.savefig(fn.replace('png', 'pdf'), bbox_inches='tight', pad_inches=0)

def savefignoborder(filename): 
    pl.gca().xaxis.set_major_locator(pl.NullLocator())
    pl.gca().yaxis.set_major_locator(pl.NullLocator())
    pl.savefig(filename, bbox_inches = 'tight', pad_inches=0.1/2.54, dpi=300)

def plot_radar(x, x_range, l_text, color_i='b', plot_axis=False, x_std=[]): 
    n_d = x.shape[0]
    x_i = np.zeros((n_d + 1, ))
    y_i = np.zeros((n_d + 1, ))
    x_i_min = np.zeros((n_d + 1, ))
    y_i_min = np.zeros((n_d + 1, ))
    x_i_max = np.zeros((n_d + 1, ))
    y_i_max = np.zeros((n_d + 1, ))
    
    if len(x_std): 
        xy = np.zeros((2 * n_d + 2, 2))
    for i in range(n_d): 
        alpha = i / n_d * 2 * np.pi
        x_i[i] = (x[i] - x_range[i, 0]) / (x_range[i, 1] - x_range[i, 0]) * np.cos(alpha)
        y_i[i] = (x[i] - x_range[i, 0]) / (x_range[i, 1] - x_range[i, 0]) * np.sin(alpha)
        if len(x_std): 
            xy[i, 0] = (x[i] + x_std[i] - x_range[i, 0]) / (x_range[i, 1] - x_range[i, 0]) * np.cos(alpha)
            xy[i, 1] = (x[i] + x_std[i] - x_range[i, 0]) / (x_range[i, 1] - x_range[i, 0]) * np.sin(alpha)
            xy[2 * n_d + 1 - (i + 1), 0] = (x[i] - x_std[i] - x_range[i, 0]) / (x_range[i, 1] - x_range[i, 0]) * np.cos(alpha)
            xy[2 * n_d + 1 - (i + 1), 1] = (x[i] - x_std[i] - x_range[i, 0]) / (x_range[i, 1] - x_range[i, 0]) * np.sin(alpha)
        if plot_axis == True: 
            pl.plot([0, np.cos(alpha)], [0, np.sin(alpha)], 'k')
            pl.text(1.3 * np.cos(alpha), 1.3 * np.sin(alpha), l_text[i], 
                 horizontalalignment='center', verticalalignment='center')
    x_i[n_d] = x_i[0]
    y_i[n_d] = y_i[0]
    fig = pl.gcf()
    ax = pl.gca()
    if len(x_std): 
        xy[n_d, 0] = xy[0, 0]
        xy[n_d, 1] = xy[0, 1]
        xy[2 * n_d + 1, 0] = xy[n_d + 1, 0]
        xy[2 * n_d + 1, 1] = xy[n_d + 1, 1]
        p = patches.Polygon(xy, figure=fig, facecolor=color_i, edgecolor='none', alpha = 0.1)
        ax.add_patch(p)
    else: 
        xy = []
    ax.plot(x_i, y_i, color=color_i)
    pl.axis('equal')
    return xy

def plot_rat(df_db, name, n_l, s_density, **kwargs):
    fn ='../data/cD4/{0}_cD4.csv'.format(name)
    res = get_C_no_mvt(df_db, name, fn, i=4, n_l=n_l, th=0)
    fmri_x = res[0]
    n_sig = fmri_x.shape[0]
    (th_min, th) = approx_ci_subsamp(n_sig, 4, 0, P_BONF)
    C = res[2]
    val = res[4]
    th_2 = max(val, th)
    print(val, th, th_2)
    A = (abs(C) > th_2).astype('int')
    g = igraph.Graph.Adjacency(A.tolist(), mode=igraph.ADJ_UNDIRECTED)
    vd = g.community_fastgreedy()
    cl1 = vd.as_clustering(vd.optimal_count)
    # print("optimal_count: " + str(vd.optimal_count))
    colors_v = [''] * n_l
    for (i, v) in enumerate(g.vs): 
        colors_v[i] = (0, 0, 0)

    nc = len(cl1)
    size_c = pl.zeros((nc, ))
    for (i, c) in enumerate(cl1): 
        size_c[i] = len(c)
    asortc = pl.argsort(size_c)

    for (i, c) in enumerate(cl1): 
        # print(c)
        if len(c) > 1: 
            #print(k)
            k1 = pl.where(asortc == i)[0]
            k = nc - k1[0] - 1
            for j in c: 
                #print(int(cmGB[k, 0])/255, int(cmGB[k, 1])/255, int(cmGB[k, 2])/255)
                colors_v[j] = (cmGB[k, 0]/255, cmGB[k, 1]/255, cmGB[k, 2]/255)
                # print(colors_v[i])
        else: 
            i = c[0]
            #print(i)
            colors_v[i] = (0.75, 0.75, 0.75)
    s_n_l = str(n_l)
    # print(g.density())
    name_rat = name
    i_rat = int(pl.where(df_db['NAME'] == name)[0])
    group = df_db['GROUP'][i_rat]
    groupname = L_GROUP_NAME[L_GROUP.index(group)]
    doc_name = str(i_rat) + ' ' + groupname + '\n' + name
    fn = '../fig/no_mvt_' + s_density + '_' + name_rat 
    print(name_rat, name, fn)
    savefig_graph(g, fn + '.png', labels=L_AREA, vertex_size=7, edge_size=0.5, 
        alpha_edges=0.5, colors=colors_v, flag_marker=False, flag_label=False, 
        flag_density=True, mode='light', metadata=(val, 1, doc_name), **kwargs)

def plot_sig_mov(name, figsize=(12,6)): 
    (t, mx, hr, rr, temp, coreg) = get_sig_mov(name)
    fig = pl.figure(figsize=figsize)
    pl.plot(t, minmax(mx, (0, 10)), 'k')
    for i in range(51): 
        pl.plot(t, minmax(x[:, i], (0, 10)), 'k', alpha=0.1)
    for i in range(6): 
        pl.plot(t, minmax(coreg[:, i], (-1, 1)) + 1, alpha=0.2, color='m')
    pl.plot(t, minmax(rr, (40, 100)) + 2, alpha=1, color='b')
    pl.plot(t, minmax(hr, (50, 400)) + 3, alpha=1, color='r')
    pl.plot(t, minmax(temp, (37, 39)) + 4, alpha=1, color='g')
    pl.plot(t, minmax(spo2, (60, 100)) + 5, alpha=1, color='r')
    pl.plot(t, minmax(err, (0, 10)) + 6, alpha=1, color='g')
    pl.xlabel('time (s)')
    return fig

def plot_test_val(l_val, y_text, ax, level=0.01, test='ttest_ind', **kwargs): 
    res = get_test_val(l_val, level=level, test=test)
    for (i, s) in enumerate(res[3]): 
        ax.text(i, y_text, s, **kwargs)
    return res

def get_sig_mov(name): 
    fn = '../data/raw/{0}_raw.csv'.format(name)
    df_raw = pd.read_csv(fn)
    x = df_raw[L_AREA].values
    rr = df_raw['RESP_RATE'].values
    temp = df_raw['TEMP_1'].values
    spo2 = df_raw['SPO2'].values
    hr = df_raw['HEART_RATE'].values
    err = df_raw['ERROR_CODE'].values
    fn_coreg = '../data/coreg/rp_' + name + '.txt'
    coreg = pl.loadtxt(fn_coreg)
    t = pl.arange(0, 1800, 0.5)
    mx = pl.mean(x, 1)
    return (t, mx, hr, rr, temp, coreg)

def get_test_val(l_val, level=0.01, test='ttest_ind'):
    """
    l_val list of values, each elem contains an array like
    
    n_val = len(l_val)
    
    
    """
    if test == 'ttest_ind': 
        funstat = stats.ttest_ind
    elif test == 'ranksums': 
        funstat = stats.ranksums
    elif test == "wilcoxon": 
        funstat = stats.wilcoxon
    else: 
        print('unknown test')
        return None
    n_val = len(l_val)
    stats_t = pl.zeros((n_val, n_val))
    stats_p = pl.zeros((n_val, n_val))
    
    for i in range(n_val): 
        stats_p[i,i] = 0.5 # p_mid = x + x.t = 1
        if type(l_val[i]) == list: 
            l_val_i = pl.array(l_val[i])
        else: 
            l_val_i= l_val[i]
        l_val_1 = l_val_i[pl.invert(pl.isnan(l_val_i))]            
        for j in range(i + 1, n_val):
            if type(l_val[j]) == list: 
                l_val_j = pl.array(l_val[j])
            else: 
                l_val_j = l_val[j]
            l_val_2 = l_val_j[pl.invert(pl.isnan(l_val_j))]
            if (len(l_val_1) < 2) | (len(l_val_2) < 2): # pb of estimation if nb data < 2 
                stats_t[i, j] = pl.nan
                stats_p[i, j] = -1
            else: 
                res = funstat(l_val_1, l_val_2)
                stats_t[i, j] = res.statistic
                stats_p[i, j] = res.pvalue
    stats_t += stats_t.T
    stats_p += stats_p.T
    # print(stats_p, level)
    stats_H0 = (stats_p > level)
    l_mkr = []
    for i in range(n_val): 
        s = ""
        for j in range(n_val): 
            if (i == j): 
                s += '◦' #r'$\circ$'
            else: 
                s += stats_str(stats_p[i, j])
        l_mkr.append(s)
    return (stats_t, stats_p, stats_H0, l_mkr)
    
def stats_str(x): 
    if pl.isnan(x): 
        return '•' #r'$\bullet$'
    if x == -1: 
        return '•' #r'$\bullet$'
    if x > 0.05: 
        s = '−' #r'$-$'
    else: 
        if x > 0.01: 
            s = '+' #r'$+$'
        else: 
            if x > 0.001: 
                s = 'x' #r'$\times$'
            else: 
                s = '†' #r'$\dagger$'
    return s

def remove_nan(x, y):
    """
    >>> x = array([1, 2, NaN])
    >>> y = array([NaN, 1, 0])
    >>> tools.remove_nan(x, y)
    (array([2.]), array([1.]))
    """
    if type(x) == list: 
        x = pl.array(x)
    if type(y) == list: 
        y = pl.array(y)
    i_x = pl.isnan(x)
    i_y = pl.isnan(y)
    i_nan = (i_x | i_y)
    i_ret = pl.invert(i_nan)
    return (x[i_ret], y[i_ret])

def plot_lr(x, y, ax, x_reg_1, x_reg_2, y_loc, mod=1, color='k', s_1='', 
    **kwargs): 
    (x, y) = remove_nan(x, y)
    res = stats.linregress(x, y)
    y_reg_1 = res.slope * x_reg_1 + res.intercept
    y_reg_2 = res.slope * x_reg_2 + res.intercept
    ax.plot([x_reg_1, x_reg_2], [y_reg_1, y_reg_2], ':', color=color)
    if mod==1: 
        s_1 += 'y = {0:2.1f} x + {1:2.0f}, R: '.format(res.slope, res.intercept)
    elif mod==2: 
        s_1 += 'y = {0:3.2f} x + {1:2.0f}, R: '.format(res.slope, res.intercept)
    elif mod==3: 
        s_1 += 'y = {0:4.3f} x + {1:2.0f}, R: '.format(res.slope, res.intercept)
    elif mod==4: 
        s_1 += 'y = {0:5.4f} x + {1:3.1f}, R: '.format(res.slope, res.intercept)
    elif mod==5: 
        s_1 += 'R: '.format(res.slope, res.intercept)
    elif mod==6: 
        s_1 += 'y = {0:5.3g} x + {1:5.3g}, R: '.format(res.slope, res.intercept)
    else: 
        s_1 += 'R: '.format(res.slope, res.intercept)
    s_1 += str(pl.around(res.rvalue, 2)) + ' (' + stats_str(res.pvalue) + ')'    
    ax.text(x_reg_1, y_loc, s_1, color=color, **kwargs)
    return res

def upper_c_to_C(c_u, n, l_ij):
    """
    >>> c_u = np.array([2, 3, 4])
    >>> upper_c_to_C(c_u, 3, tools.get_l_ij_to_i_j(3))

    array([[0., 2., 3.],
       [2., 0., 4.],
       [3., 4., 0.]])
    """
    C = np.zeros((n, n))
    for (ij, c_ij) in enumerate(c_u): 
        i = l_ij[ij][0]
        j = l_ij[ij][1]
        C[i, j] = c_ij
        C[j, i] = c_ij
    return C
    
#_______________________________________________________________________________
phi_inv = distributions.norm.ppf

def fun_h(rho): 
    y = pl.arctanh(rho)
    return y

def fun_N_j(N, j, L=8): 
    L_j_p = (L - 2) * (1 - 2 ** (-j))
    N_j = N / (2 ** j) - (pl.ceil(L_j_p))
    return N_j

def approx_ci(N, j, rho, p, L=8): 
    """
    N: int, number of samples
    j: int, level
    rho: estimated correlation value
    p: float, set the level of the CI interval (100 * (1 - 2 * p) % CI)
    """
    N_j_hat = fun_N_j(N, j, L=L)
    if (N_j_hat < 4):
        rho_min = np.nan
        rho_max = np.nan
    else: 
        rho_min = pl.tanh(fun_h(rho) - 
            (phi_inv((1 - p)) / pl.sqrt((N_j_hat - 3))))
        rho_max = pl.tanh(fun_h(rho) + 
            (phi_inv((1 - p)) / pl.sqrt((N_j_hat - 3))))
    return (rho_min, rho_max)

def approx_ci_subsamp(N, j, rho, p, L=8): 
    """
    N: int, number of samples
    j: int, level
    rho: estimated correlation value
    p: float, set the level of the CI interval (100 * (1 - 2 * p) % CI)
    """
    N_j_hat = N / (2 ** j) 
    if (N_j_hat < 4):
        rho_min = np.nan
        rho_max = np.nan
    else: 
        rho_min = pl.tanh(fun_h(rho) - 
            (phi_inv((1 - p)) / pl.sqrt((N_j_hat - 3))))
        rho_max = pl.tanh(fun_h(rho) + 
            (phi_inv((1 - p)) / pl.sqrt((N_j_hat - 3))))
    return (rho_min, rho_max)

def approx_ci_simu(N, j): 
    """
    N: int, number of samples
    j: int, level
    rho: estimated correlation value
    p: float, set the level of the CI interval (100 * (1 - 2 * p) % CI)
    values approximated from experimental tests.
    """
    k = divmod(N, 500)[0]
    M = pl.array([
            [0.20, 0.15, 0.10, 0.09, 0.08, 0.07, 0.06, 0.05], 
            [0.20, 0.15, 0.10, 0.09, 0.08, 0.07, 0.06, 0.05],
            [0.30, 0.20, 0.15, 0.10, 0.09, 0.08, 0.07, 0.06],
            [0.40, 0.30, 0.20, 0.15, 0.10, 0.09, 0.08, 0.07],
            [0.60, 0.40, 0.30, 0.20, 0.15, 0.10, 0.09, 0.08], 
            [0.75, 0.50, 0.40, 0.30, 0.20, 0.15, 0.10, 0.09], 
            [0.90, 0.75, 0.50, 0.40, 0.30, 0.20, 0.15, 0.10]])
    rho = M[j-1, k] 
    return rho

#_______________________________________________________________________________


def bin_x_y(x, y, n, x_min, x_max): 
    """
    x: ndarray ((nobs, ))
    y: ndarray ((nobs, )), values to average inside bins
    n: int, number of bins
    x_min, x_max: interval (x_min <= x < x_max) 
    
    Example 
    
    x = array([1, 2, 2, 2, 4])
    y = array([1, 1, 2, 2, 3])
    res = tools.bin_x_y(x, y, 5, 0, 4.1)
    print(res)
    
    """
    list_val = pl.linspace(x_min, x_max, n + 1)
    list_y = []
    for i in range(n): 
        cond = (list_val[i] <= x) & (x < list_val[i + 1])
        if any(cond): 
            y_i = y[cond] 
        else: 
            y_i = pl.array([0])
        list_y.append(y_i)
    y_m = pl.zeros((n, ))
    y_sem = pl.zeros((n, ))
    x_c = (list_val[:-1] + list_val[1:]) / 2
    #print(list_y)
    for i in range(n): 
        y_i = list_y[i]
        n_i = y_i.shape[0]
        y_m[i] = pl.mean(y_i)
        y_sem[i] = pl.std(y_i) / pl.sqrt(n_i)
    return (x_c, y_m, y_sem)

def get_i_lag_ws(j, L=8): 
    """
    get the index of the lag for the wavelet coefficient at scale j with a an original wavelet length of L.
    
    example
    
    >>> i_lag = get_i_lag_ws(1, L=4)
    
    
    >>> i_lag = get_i_lag_ws(1, L=5)
    
    """
    if j == 0: 
        return 0
    else: 
        i_lag = (L - 1) * (2 ** (j - 1)) + 1
        return i_lag

def get_framewise_displacement(x):
    """
    see Power et al. 
    x comes from SPM coregistration files. rp_*.txt 
    0, 1, 2: translation in x, y, z in mm 
    3, 4, 5: rotation phi, theta, psi in rad
    
    Measures on rats have been multiplied by 10 in SPM to match parameters of human studies. 
    
    For framewise displacement, translations are divided by 10. 
    rotations are transformed to displacement by multiplying by the maximal radius of rotation for the rat head, set to 10 mm here. 
    
    fd[0] is set to 0
    
    """
    x = x.copy()
    fd = np.zeros((x.shape[0],))
    # translations / 10
    for i in range(0, 3): 
        x[:, i] /= 10
    # rotations * 10 
    for i in range(3, 6): 
        x[:, i] *= 10
    dx = np.diff(x, 1, 0)
    fd[1:] = np.sum(np.abs(dx), 1)
    return fd

def stat_one_group(df, group): 
    df_this_group = df[df.GROUP == group]
    df_des = df_this_group.describe()
    print(group)
    print(df_des[['WEIGHT', 'TEMP', 'HR', 'RR', 'SPO2', 'CBF']])
    return None   

def boxplot_per_group(df, values, y_label='', y_lim=None, y_tick=None, 
    ax=None, test='ranksums', **kwargs): 
    df2 = df.pivot(columns="GROUP", values=values)
    ax = df2.plot.box(rot=90, ax=ax, zorder=0, )
    ax.set_ylabel(y_label)
    des = df2.describe()
    n_group = df2.shape[1]
    l_val = []
    if not(y_lim): 
        y_max = amax(df[values])
        y_min = amin(df[values])
    else: 
        y_min = y_lim[0]
        y_max = y_lim[1]
    y_range = y_max - y_min
    y_stat = y_max + 0.2 * y_range
    for i in range(n_group): 
        val_1 = df2.iloc[:, i].values
        val_group = val_1[pl.isfinite(val_1)]
        # ax.boxplot(val_group, positions=[int(i+1)])
        # cond = (val_group > y_min) & (val_group < y_max)
        # val_group = val_group[cond]
        l_val.append(val_group)
        if any(val_group < y_min): 
            ax.scatter(i + 1, y_min, color='w', marker='s', edgecolors='k')
        if any(val_group > y_max): 
            ax.scatter(i + 1, y_max, color='w', marker='s', edgecolors='k')
    r1 = pl.Rectangle((0, y_max), n_group+1, y_max + 0.25 * y_range, facecolor='w', edgecolor='k', zorder=1)
    ax.add_patch(r1)
    res = get_test_val(l_val, test=test)
    for (i, s) in enumerate(res[3]): 
        ax.text(i + 1, y_stat, s, family='monospace', 
                horizontalalignment='center', verticalalignment='center', rotation=90, fontsize=8)
    ax.set_ylim(y_min, y_max + 0.4 * y_range)
    ax.set_xlim(0, n_group + 1)
    ax.set_xticks(pl.arange(1, 7))
    u_g = pl.unique(df['GROUP'])
    l_groupname = []
    for g in u_g: 
        i_g = L_GROUP.index(g)
        l_groupname.append(L_GROUP_NAME[i_g])
    ax.set_xticklabels(l_groupname)
    if y_tick: 
        ax.set_yticks(pl.arange(y_min, y_max + 0.5 * y_tick, y_tick))
    else: 
        ax.set_yticks([y_min, y_max])       
    return des, val_1
    
def get_lim(x, x_lim=None): 
    if not(x_lim): 
        x_max = amax(x)
        x_min = amin(x)
    else: 
        x_min = x_lim[0]
        x_max = x_lim[1]
    x_range = x_max - x_min
    return (x_min, x_max, x_range)
    
def check_range(x_1, x_2, x_min, x_max):
    c_x = False
    if (x_1 < x_min): 
        x_1 = x_min
        x_2 = pl.nan
        c_x = True
    if (x_1 > x_max): 
        x_1 = x_max
        x_2 = pl.nan
        c_x = True
    return (x_1, x_2, c_x)

def scatter_xy(df, name_x, name_y, 
               ax=None, x_label=None, y_label=None, 
               x_lim=None, y_lim=None, x_tick=None, y_tick=None, mod=1): 
    x = df[name_x].values
    y = df[name_y].values
    i_finite_x = pl.isfinite(x)
    i_finite_y = pl.isfinite(y)
    i_finite = (i_finite_x & i_finite_y)
    x_2 = x[i_finite]
    y_2 = y[i_finite]
    x_3 = x[i_finite]
    y_3 = y[i_finite]
    group = df['GROUP'].values[i_finite]
    (x_min, x_max, x_range) = get_lim(x_2, x_lim)
    (y_min, y_max, y_range) = get_lim(y_2, y_lim)
    #print((x_min, x_max, x_range), (y_min, y_max, y_range))
    if not(ax): 
        ax = axes()
    for k in range(x_2.shape[0]): 
        i_g = L_GROUP.index(group[k])
        marker_i = L_GROUP_MARKER[i_g]
        #print(i_g, end=', ')
        (x_2[k], x_3[k], c_x) = check_range(x_2[k], x_3[k], x_min, x_max)
        (y_2[k], y_3[k], c_y) = check_range(y_2[k], y_3[k], y_min, y_max)
        if (c_x | c_y):
            marker_i = 's'
        ax.plot(x_2[k], y_2[k], '.', marker=marker_i, color=L_GROUP_COLOR[i_g], alpha=0.75)
    ax.axis([x_min, x_max, y_min, y_max])
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    r1 = pl.Rectangle((x_min, y_max), x_range, 0.25 * y_range, facecolor='w', edgecolor='k', zorder=1)
    ax.add_patch(r1)
    plot_lr(x_3, y_3, ax, x_min, x_max, y_max + 0.125 * y_range, 
        mod=mod, s_1='     ', verticalalignment='center', fontsize=8)
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_min, y_max + 0.25 * y_range)
    if x_tick: 
        ax.set_xticks(pl.arange(x_min, x_max + 0.5 * x_tick, x_tick))
    if y_tick: 
        ax.set_yticks(pl.arange(y_min, y_max + 0.5 * y_tick, y_tick))
    if x_label: 
        ax.set_xlabel(x_label)
    if y_label: 
        ax.set_ylabel(y_label)      

def get_value_physio(name, group): 
    fn = '../data/raw/' + name + '_raw.csv'
    df_raw = pd.read_csv(fn)
    x = df_raw[L_AREA].values
    rr = df_raw['RESP_RATE'].values
    hr = df_raw['HEART_RATE'].values
    temp = df_raw['TEMP_1'].values
    spo2 = df_raw['SPO2'].values
    err = df_raw['ERROR_CODE'].values
    cond_err_0 = (df_raw['ERROR_CODE'] == 0)
    #rr_all_m = rr.mean()
    #hr_all_m = hr.mean()
    #temp_all_m = temp.mean()
    #spo2_all_m = spo2.mean()
    n_err_0 = pl.sum(cond_err_0)
    if group == 'DEAD': 
        err_rate = pl.nan
        rr_m = pl.nan
        hr_m = pl.nan
        temp_m = pl.nan
        spo2_m = pl.nan
    else: 
        err_rate = (3600 - n_err_0) / 3600 * 100 # error rate in %
        if n_err_0 == 0: 
            rr_m = pl.nan
            hr_m = pl.nan
            temp_m = pl.nan
            spo2_m = pl.nan
        else: 
            rr_m = rr[cond_err_0].mean()
            hr_m = hr[cond_err_0].mean()
            temp_m = temp[cond_err_0].mean()
            spo2_m = spo2[cond_err_0].mean()
    return (rr_m, hr_m, temp_m, spo2_m, err_rate)
